console.log("DECLARE LOAD AND PREPROCESS");


/*************************************************************
						Loading Variables
*************************************************************/
function declare_loading_global_variabes() {
	console.log("declare_loading_global_variabes");
	//variables of loading
	window.stringData;
}


/*************************************************************
						Preprocessing Variables
*************************************************************/
function declare_preprocessing_global_variabes() {
	console.log("declare_preprocessing_global_variabes");
	//variables of preprocessing
	window.arrayOfObjectsData = [];
	window.dataFrameCSV;

}


